"""Source temporal classifier and a paired, shared-mask dropout preference scorer."""
import torch
from torch import nn
from torch.nn import functional as F


class ConvEncoder(nn.Module):
    """Three Conv1d-BN-ReLU blocks with 64/128/128 filters, global pooling."""
    def __init__(self, in_channels: int):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv1d(in_channels, 64, 7, padding=3), nn.BatchNorm1d(64), nn.ReLU(),
            nn.Conv1d(64, 128, 5, padding=2), nn.BatchNorm1d(128), nn.ReLU(),
            nn.Conv1d(128, 128, 3, padding=1), nn.BatchNorm1d(128), nn.ReLU(),
            nn.AdaptiveAvgPool1d(1), nn.Flatten(),
        )
        self.out_dim = 128

    def forward(self, x):
        if x.ndim != 3:
            raise ValueError("Input must be [batch, channels, length]")
        return self.net(x)


class TemporalClassifier(nn.Module):
    def __init__(self, in_channels: int, num_classes: int):
        super().__init__()
        self.encoder = ConvEncoder(in_channels)
        self.classifier = nn.Linear(self.encoder.out_dim, num_classes)
        self.in_channels = in_channels
        self.num_classes = num_classes

    def forward(self, x):
        return self.classifier(self.encoder(x))

    def freeze_classifier(self):
        self.classifier.requires_grad_(False)
        self.classifier.eval()


class PreferenceScorer(nn.Module):
    """Bradley-Terry shared scorer with *paired* MC dropout masks.

    A dropout mask is sampled once per pair and shared for the source and target
    descriptor. Thus swapping source/target exactly reverses score difference
    for a fixed mask, preserving the BT pairwise structure.
    """
    def __init__(self, descriptor_dim: int, hidden_dim: int = 128, dropout: float = 0.2):
        super().__init__()
        if not 0 <= dropout < 1:
            raise ValueError("dropout must be within [0,1)")
        self.layers = nn.ModuleList([
            nn.Linear(descriptor_dim, hidden_dim),
            nn.Linear(hidden_dim, hidden_dim),
        ])
        self.out = nn.Linear(hidden_dim, 1)
        self.dropout = dropout

    def paired_scores(self, descriptor_s, descriptor_t, stochastic=True):
        a, b = descriptor_s, descriptor_t
        for layer in self.layers:
            a = F.relu(layer(a))
            b = F.relu(layer(b))
            if stochastic and self.dropout > 0:
                mask = (torch.rand_like(a) >= self.dropout).to(a.dtype) / (1.0 - self.dropout)
                a, b = a * mask, b * mask
        return self.out(a).squeeze(-1), self.out(b).squeeze(-1)

    def forward(self, descriptor_s, descriptor_t, stochastic=True):
        score_s, score_t = self.paired_scores(descriptor_s, descriptor_t, stochastic)
        return torch.sigmoid(score_t - score_s)

    def regularizer(self):
        """L2 surrogate for dropout-variational KL, NOT an exact analytic KL."""
        return sum(p.square().sum() for p in self.parameters())
