"""Exact kernel construction and incremental-Cholesky greedy acquisition."""
import math
import torch
import torch.nn.functional as F

from .objectives import fourier_descriptors


def build_joint_kernel(embeddings, windows, sigma_z, xi, eps=1e-8):
    """Eq. kernel: RBF normalized embeddings * (1 + xi cosine Fourier magnitudes).

    This materializes an NxN kernel (O(N^2) memory). For huge target streams,
    use a stratified candidate pool and disclose the approximation.
    """
    z = F.normalize(embeddings.float(), p=2, dim=-1, eps=eps)
    f = fourier_descriptors(windows, eps)
    d2 = torch.cdist(z, z, p=2).square().clamp_min(0)
    kz = torch.exp(-d2 / (2.0 * sigma_z ** 2))
    kf = 1.0 + xi * (f @ f.T)
    kernel = kz * kf
    return (kernel + kernel.T) * 0.5


def subset_objective(kernel, uncertainty, soft_targets, selected, gamma, lambda_b):
    """Eq. acq evaluated for arbitrary subset (mainly used in tests)."""
    if len(selected) == 0:
        return 0.0
    idx = torch.as_tensor(selected, dtype=torch.long, device=kernel.device)
    sub = kernel[idx[:, None], idx[None, :]]
    identity = torch.eye(idx.numel(), device=sub.device, dtype=sub.dtype)
    sign, val = torch.linalg.slogdet(identity + sub)
    if sign <= 0:
        raise RuntimeError("I+K_A was not positive definite")
    return float((torch.log1p(uncertainty[idx]).sum() + gamma * val +
                  lambda_b * torch.log1p(soft_targets[idx].sum(0)).sum()).item())


def round_budget(n, r, rounds, rho_min, rho_max):
    """Round r is one-based; Eq. curriculum budget."""
    if r < 1 or r > rounds:
        raise ValueError("r must be between 1 and rounds")
    rho = rho_min + (rho_max - rho_min) * (r - 1) / max(1, rounds - 1)
    return min(n, max(1, math.floor(rho * n)))


def greedy_select(kernel, uncertainty, soft_targets, budget, gamma=0.5, lambda_b=0.1, eps=1e-10):
    """Greedily maximize exact Eq. acq marginal gains.

    For logdet(I+K_A), the current gain for candidate i is log(r_i) where
    r_i is its remaining Schur-complement diagonal. Rank-one pivoted Cholesky
    updates every r_i, avoiding repeated slogdet calls for all candidates.
    Complexity O(NB^2) time, O(NB) extra storage beyond the NxN kernel.
    """
    if kernel.ndim != 2 or kernel.shape[0] != kernel.shape[1]:
        raise ValueError("kernel must be square")
    n = kernel.shape[0]
    if uncertainty.shape != (n,) or soft_targets.shape[0] != n:
        raise ValueError("Dimension mismatch in greedy_select")
    if n == 0 or budget <= 0:
        return torch.empty(0, dtype=torch.long, device=kernel.device)
    if gamma < 0 or lambda_b < 0:
        raise ValueError("gamma and lambda_b must be nonnegative")
    budget = min(n, int(budget))
    kernel = kernel.detach()
    uncertainties = uncertainty.detach()
    soft_targets = soft_targets.detach()
    base = torch.log1p(uncertainties)
    remaining = 1.0 + kernel.diagonal().clone()
    chosen = torch.zeros(n, dtype=torch.bool, device=kernel.device)
    factor = torch.zeros((n, budget), dtype=kernel.dtype, device=kernel.device)
    class_mass = torch.zeros(soft_targets.size(1), device=kernel.device, dtype=soft_targets.dtype)
    result = []
    for b in range(budget):
        marginal = base + gamma * remaining.clamp_min(eps).log()
        if lambda_b:
            marginal = marginal + lambda_b * torch.log1p(soft_targets / (1 + class_mass)).sum(-1)
        marginal[chosen] = -torch.inf
        idx = int(torch.argmax(marginal).item())
        if not torch.isfinite(marginal[idx]):
            raise RuntimeError("Nonfinite acquisition score")
        result.append(idx)
        chosen[idx] = True
        class_mass += soft_targets[idx]
        # Off-diagonal k_is correction from the previous Cholesky columns.
        column = kernel[:, idx].clone()
        if b:
            column -= factor[:, :b] @ factor[idx, :b]
        # Diagonal belongs to I + K, not just K.
        column[idx] += 1.0
        pivot = remaining[idx].clamp_min(eps).sqrt()
        next_factor = column / pivot
        factor[:, b] = next_factor
        remaining -= next_factor.square()
        remaining.clamp_(min=eps)
    return torch.tensor(result, dtype=torch.long, device=kernel.device)
