"""BHPTC alternating target-only optimization (paper Algorithm 1)."""
from dataclasses import asdict
import random

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F

from .augment import paired_views
from .config import BHPTCConfig
from .curriculum import build_joint_kernel, greedy_select, round_budget
from .models import PreferenceScorer, TemporalClassifier
from .objectives import (
    descriptor, fuse_hypotheses, learning_emphasis, mc_epistemic,
    mutual_information, projection_loss, source_posteriors,
    target_posteriors, temporal_consistency_loss, update_prototypes,
    weak_comparisons, weak_utilities,
)


def seed_everything(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def minibatches(n, batch_size, shuffle=False):
    """Generate indices; merge a singleton batch to allow BatchNorm training."""
    indices = torch.randperm(n) if shuffle else torch.arange(n)
    batches = list(indices.split(batch_size))
    if len(batches) > 1 and batches[-1].numel() == 1:
        batches[-2] = torch.cat((batches[-2], batches[-1]))
        batches.pop()
    return batches


class BHPTCAdapter:
    """Source-free target adaptation: accepts x only; never accesses target labels.

    Arguments:
        model: source-trained TemporalClassifier, encoder copied by loading weights.
        cfg: config; source data is not accepted by this API.
        device: torch device; CPU works for smaller datasets.
    """
    def __init__(self, model: TemporalClassifier, cfg: BHPTCConfig, device="cpu"):
        self.cfg = cfg.validate()
        self.device = torch.device(device)
        self.model = model.to(self.device)
        self.model.freeze_classifier()
        self.model.train()
        self.model.classifier.eval()
        m = model.num_classes
        self.preference = PreferenceScorer(
            self.model.encoder.out_dim + 3 * m,
            cfg.preference_hidden, cfg.preference_dropout
        ).to(self.device)
        # c^(0) is the normalized source classifier class direction a_m.
        self.prototypes = F.normalize(self.model.classifier.weight.detach().clone(), dim=-1, eps=cfg.eps)
        self.history = []

    @torch.no_grad()
    def update_target_bn_statistics(self, x):
        """Refresh encoder BN moments on UNLABELED target x, before target optimization."""
        if x.shape[0] < 2:
            raise ValueError("At least 2 target windows are needed for BatchNorm")
        self.model.encoder.train()
        for idx in minibatches(len(x), self.cfg.batch_size):
            batch = x[idx].to(self.device)
            self.model.encoder(batch)
        self.model.encoder.eval()

    @torch.no_grad()
    def collect_hypotheses(self, x):
        """Collect original/augmented hypotheses with a frozen snapshot of theta."""
        cfg = self.cfg
        self.model.eval()
        store = {k: [] for k in ("z", "ps", "zw", "zs", "psw", "pss")}
        for idx in minibatches(len(x), cfg.batch_size):
            batch = x[idx].to(self.device)
            weak, strong = paired_views(batch, cfg)
            z = self.model.encoder(batch)
            zw = self.model.encoder(weak)
            zs = self.model.encoder(strong)
            ps = source_posteriors(self.model.classifier(z), cfg.source_temperature)
            psw = source_posteriors(self.model.classifier(zw), cfg.source_temperature)
            pss = source_posteriors(self.model.classifier(zs), cfg.source_temperature)
            for name, tensor in (("z", z), ("ps", ps), ("zw", zw), ("zs", zs),
                                 ("psw", psw), ("pss", pss)):
                store[name].append(tensor.detach())
        state = {k: torch.cat(v, dim=0) for k, v in store.items()}
        self.prototypes = update_prototypes(state["z"], state["ps"], self.prototypes,
                                           cfg.prototype_momentum, cfg.eps)
        pt = target_posteriors(state["z"], self.prototypes, cfg.target_temperature, cfg.eps)
        ptw = target_posteriors(state["zw"], self.prototypes, cfg.target_temperature, cfg.eps)
        pts = target_posteriors(state["zs"], self.prototypes, cfg.target_temperature, cfg.eps)
        us = weak_utilities(state["ps"], state["psw"], state["pss"], cfg.utility_eta)
        ut = weak_utilities(pt, ptw, pts, cfg.utility_eta)
        mask, weak_labels = weak_comparisons(us, ut, cfg.delta)
        ds = descriptor(state["z"], state["ps"], state["psw"], state["pss"], cfg.eps)
        dt = descriptor(state["z"], pt, ptw, pts, cfg.eps)
        return {"z": state["z"], "ps": state["ps"], "pt": pt,
                "ds": ds, "dt": dt, "weak_mask": mask, "weak_labels": weak_labels}

    def train_preference(self, state):
        """Update q(phi) iff Omega nonempty. L2 approximates dropout KL term."""
        cfg = self.cfg
        qualified = torch.where(state["weak_mask"])[0]
        if qualified.numel() == 0:
            return None
        optim = torch.optim.Adam(self.preference.parameters(), lr=cfg.preference_lr)
        self.preference.train()
        last_loss = None
        for _ in range(cfg.preference_epochs_per_round):
            for batch_ids in minibatches(len(qualified), cfg.batch_size, shuffle=True):
                ids = qualified[batch_ids]
                q = self.preference(state["ds"][ids], state["dt"][ids], stochastic=True)
                labels = state["weak_labels"][ids]
                bce = F.binary_cross_entropy(q.clamp(1e-6, 1 - 1e-6), labels)
                # Dropout approximation KL(q(phi)||p(phi)), not analytic equality.
                kl_proxy = 0.5 * cfg.preference_beta / len(qualified) * self.preference.regularizer()
                loss = bce + kl_proxy
                optim.zero_grad(set_to_none=True)
                loss.backward()
                optim.step()
                last_loss = float(loss.detach().item())
        return last_loss

    @torch.no_grad()
    def evaluate_preference(self, state):
        """Per-datum mean and variance; batches bound MC memory use."""
        means, variances = [], []
        self.preference.eval()  # MC masks still enabled explicitly in forward(...).
        n = len(state["ds"])
        for ids in minibatches(n, self.cfg.batch_size):
            mean, var = mc_epistemic(self.preference, state["ds"][ids],
                                     state["dt"][ids], self.cfg.mc_samples)
            means.append(mean)
            variances.append(var)
        return torch.cat(means), torch.cat(variances)

    def train_encoder(self, x, soft_targets, global_pi):
        """Eq. total: D_pc + lambda_tc C_tc - lambda_im I_t.

        Uses global pi and mini-batch stochastic estimates for all objectives.
        Fused targets/prototypes/preference remain detached and frozen.
        """
        cfg = self.cfg
        optim = torch.optim.Adam(self.model.encoder.parameters(), lr=cfg.target_lr)
        self.model.encoder.train()
        self.model.classifier.eval()
        total_loss = 0.0
        steps = 0
        for _ in range(cfg.target_epochs_per_round):
            for ids in minibatches(len(x), cfg.batch_size, shuffle=True):
                batch = x[ids].to(self.device)
                clean_logits = self.model.classifier(self.model.encoder(batch))
                p = torch.softmax(clean_logits, dim=-1)
                _, augmented = paired_views(batch, cfg)
                p_aug = torch.softmax(self.model.classifier(self.model.encoder(augmented)), dim=-1)
                dp = projection_loss(soft_targets[ids], p, global_pi[ids], len(x), cfg.eps)
                tc = temporal_consistency_loss(p, p_aug, cfg.eps)
                mi = mutual_information(p, cfg.eps)
                loss = dp + cfg.lambda_tc * tc - cfg.lambda_im * mi
                optim.zero_grad(set_to_none=True)
                loss.backward()
                optim.step()
                total_loss += float(loss.detach().item())
                steps += 1
        return total_loss / max(steps, 1)

    def adapt(self, target_x, verbose=True):
        """Five-round (configurable) source-free adaptation, paper Algorithm 1.

        target_x must contain ONLY features [N,C,L]; no target labels accepted.
        """
        seed_everything(self.cfg.seed)
        x = torch.as_tensor(target_x, dtype=torch.float32).cpu().contiguous()
        if x.ndim != 3 or x.shape[1] != self.model.in_channels:
            raise ValueError("Expected target features [N, source_in_channels, length]")
        if len(x) < 2:
            raise ValueError("Need >=2 unlabeled target windows")
        self.update_target_bn_statistics(x)
        for r in range(1, self.cfg.rounds + 1):
            state = self.collect_hypotheses(x)
            pref_loss = self.train_preference(state)
            qmean, e = self.evaluate_preference(state)
            fused, alpha = fuse_hypotheses(state["ps"], state["pt"], qmean, e, self.cfg.tau_e)
            # Kernel computed on CPU to conserve accelerator memory.
            kernel = build_joint_kernel(state["z"].cpu(), x, self.cfg.sigma_z, self.cfg.xi, self.cfg.eps)
            budget = round_budget(len(x), r, self.cfg.rounds, self.cfg.rho_min, self.cfg.rho_max)
            chosen = greedy_select(kernel, e.cpu(), fused.cpu(), budget, self.cfg.gamma, self.cfg.lambda_b)
            pi, _ = learning_emphasis(fused, chosen.to(self.device), self.cfg.curriculum_kappa, self.cfg.eps)
            encoder_loss = self.train_encoder(x, fused.detach(), pi.detach())
            result = {"round": r, "weak_comparisons": int(state["weak_mask"].sum()),
                      "selected": int(len(chosen)), "preference_loss": pref_loss,
                      "encoder_loss": encoder_loss, "mean_epistemic_variance": float(e.mean()),
                      "mean_fusion_alpha": float(alpha.mean())}
            self.history.append(result)
            if verbose:
                print(f"round {r}/{self.cfg.rounds}: {result}", flush=True)
        self.model.eval()
        return self.model

    def save(self, path):
        torch.save({"model_state": self.model.state_dict(),
                    "in_channels": self.model.in_channels,
                    "num_classes": self.model.num_classes,
                    "preference_state": self.preference.state_dict(),
                    "prototypes": self.prototypes.cpu(),
                    "config": asdict(self.cfg), "history": self.history}, path)
