"""Implementation defaults. Settings unspecified in the paper are identified below."""
from dataclasses import asdict, dataclass, fields
import json
from pathlib import Path


@dataclass
class BHPTCConfig:
    # Reported in the manuscript's experimental configuration.
    rounds: int = 5
    mc_samples: int = 10
    delta: float = 0.10
    tau_e: float = 0.05
    prototype_momentum: float = 0.90
    gamma: float = 0.50
    lambda_b: float = 0.10
    rho_min: float = 0.15
    rho_max: float = 0.35
    lambda_tc: float = 0.35
    lambda_im: float = 0.10
    target_lr: float = 3e-4  # Manuscript: 3e-4 UCIHAR/MFD; 1e-5 SSC.
    # Implementation choices: not assigned unique numeric values in Methodology.
    source_temperature: float = 1.0
    target_temperature: float = 0.15
    utility_eta: float = 0.20
    sigma_z: float = 1.0
    xi: float = 1.0
    curriculum_kappa: float = 1.0
    preference_beta: float = 1e-3
    preference_dropout: float = 0.2
    preference_hidden: int = 128
    preference_lr: float = 1e-3
    preference_epochs_per_round: int = 3
    target_epochs_per_round: int = 1
    batch_size: int = 64
    acquisition_chunk_size: int = 512
    weak_jitter: float = 0.01
    strong_jitter: float = 0.05
    weak_scale: float = 0.02
    strong_scale: float = 0.10
    strong_permutation_prob: float = 0.25  # Apply with care: domain dependent.
    seed: int = 42
    eps: float = 1e-8

    def validate(self):
        if self.rounds < 1 or self.mc_samples < 2:
            raise ValueError("rounds must be >= 1 and mc_samples >= 2")
        if not 0 < self.rho_min <= self.rho_max <= 1:
            raise ValueError("require 0 < rho_min <= rho_max <= 1")
        if not 0 <= self.prototype_momentum < 1:
            raise ValueError("prototype_momentum must be in [0,1)")
        for name in ("tau_e", "sigma_z", "source_temperature", "target_temperature", "batch_size"):
            if getattr(self, name) <= 0:
                raise ValueError(f"{name} must be positive")
        for name in ("delta", "gamma", "xi", "lambda_b", "lambda_tc", "lambda_im", "curriculum_kappa", "preference_beta", "utility_eta"):
            if getattr(self, name) < 0:
                raise ValueError(f"{name} must be nonnegative")
        return self

    @classmethod
    def from_json(cls, file):
        params = json.loads(Path(file).read_text(encoding="utf-8"))
        unknown = set(params).difference(f.name for f in fields(cls))
        if unknown:
            raise ValueError(f"Unrecognized config keys: {sorted(unknown)}")
        return cls(**params).validate()

    def to_json(self, file):
        Path(file).write_text(json.dumps(asdict(self), indent=2) + "\n", encoding="utf-8")
