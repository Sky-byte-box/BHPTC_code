"""Label-preserving temporal augmentations (parameterized approximations)."""
import torch


def jitter_scale(x, jitter=0.02, scale=0.05):
    """Per-window amplitude scaling and additive Gaussian jitter."""
    amplitude = 1.0 + scale * torch.randn(x.shape[0], x.shape[1], 1, device=x.device, dtype=x.dtype)
    return x * amplitude + torch.randn_like(x) * jitter


def segment_permutation(x, max_segments=4):
    """Permute temporal segments; use only when weakly label preserving."""
    if x.shape[-1] < 4:
        return x
    n = min(max_segments, x.shape[-1])
    out = torch.empty_like(x)
    parts = [p for p in torch.tensor_split(torch.arange(x.shape[-1], device=x.device), n) if p.numel()]
    for b in range(x.shape[0]):
        order = torch.randperm(len(parts), device=x.device)
        out[b] = torch.cat([x[b, :, parts[int(j)]] for j in order], dim=-1)
    return out


def magnitude_warp(x, strength=0.08):
    """Smooth, low-frequency positive multiplicative envelope."""
    if x.shape[-1] < 4:
        return x
    control = torch.randn(x.shape[0], x.shape[1], 6, device=x.device, dtype=x.dtype)
    envelope = torch.nn.functional.interpolate(control, size=x.shape[-1], mode="linear", align_corners=True)
    return x * (1.0 + strength * torch.tanh(envelope))


def paired_views(x, cfg):
    """Weak jitter/scale and stronger jitter/scale/warp/occasional permutation."""
    weak = jitter_scale(x, cfg.weak_jitter, cfg.weak_scale)
    strong = magnitude_warp(jitter_scale(x, cfg.strong_jitter, cfg.strong_scale))
    if cfg.strong_permutation_prob > 0:
        # Permutations can change class semantics for order-sensitive tasks.
        # Disable via strong_permutation_prob=0 when this is a concern.
        mask = torch.rand(len(x), device=x.device) < cfg.strong_permutation_prob
        if mask.any():
            strong[mask] = segment_permutation(strong[mask])
    return weak, strong
