"""Mathematical components of BHPTC (paper equation references in docstrings)."""
import math
import torch
import torch.nn.functional as F


def entropy(p, eps=1e-8):
    return -(p * p.clamp_min(eps).log()).sum(dim=-1)


def source_posteriors(logits, temperature):
    """Eq. sourcehyp."""
    return F.softmax(logits / temperature, dim=-1)


def update_prototypes(z, p_s, prototypes, momentum, eps=1e-8):
    """Eq. prototype: source-soft-posterior-weighted normalized target embeddings."""
    with torch.no_grad():
        z_unit = F.normalize(z, p=2, dim=-1, eps=eps)
        p = p_s.detach()
        estimates = p.T @ z_unit / p.sum(0).unsqueeze(1).clamp_min(eps)
        return F.normalize(momentum * prototypes + (1 - momentum) * estimates, p=2, dim=-1, eps=eps)


def target_posteriors(z, prototypes, temperature, eps=1e-8):
    """Eq. targethyp."""
    return F.softmax(F.normalize(z, dim=-1, eps=eps) @ prototypes.T / temperature, dim=-1)


def weak_utilities(p, p_weak, p_strong, eta):
    """Eq. weakcomp (1 - quarter * sum of two L1 view distances + confidence)."""
    stability = 0.25 * ((p - p_weak).abs().sum(-1) + (p - p_strong).abs().sum(-1))
    return 1.0 - stability + eta * p.max(-1).values


def weak_comparisons(u_source, u_target, delta):
    """Omega and r_i as described after weakcomp."""
    diff = u_target - u_source
    return diff.abs() > delta, (diff > 0).float()


def descriptor(z, p, p_weak, p_strong, eps=1e-8):
    """Paired descriptor d_i^k (normalized embedding plus three posteriors)."""
    return torch.cat((F.normalize(z, dim=-1, eps=eps), p, p_weak, p_strong), dim=-1)


def mc_epistemic(preference_model, d_source, d_target, samples):
    """Eq. epistemic: stochastic BT probabilities, unbiased sample variance."""
    if samples < 2:
        raise ValueError("At least two MC samples required")
    estimates = torch.stack([preference_model(d_source, d_target, stochastic=True) for _ in range(samples)])
    return estimates.mean(0), estimates.var(0, unbiased=True)


def fuse_hypotheses(p_source, p_target, q_mean, variance, tau_e):
    """Eq. fusion with uncertainty-adaptive shrinkage towards alpha=0.5."""
    alpha = 0.5 + torch.exp(-variance / tau_e) * (q_mean - 0.5)
    soft_targets = (1 - alpha[:, None]) * p_source + alpha[:, None] * p_target
    return soft_targets, alpha


def fourier_descriptors(x, eps=1e-8):
    """Flattened normalized magnitude of the full channel-wise discrete Fourier transform."""
    magnitude = torch.fft.fft(x.float(), dim=-1).abs().flatten(start_dim=1)
    return F.normalize(magnitude, dim=-1, eps=eps)


def learning_emphasis(fused, selected_indices, kappa, eps=1e-8):
    """Eq. reliability: normalized global pi; uniform fallback."""
    n, m = fused.shape
    if m < 2:
        raise ValueError("At least 2 classes required")
    confidence = (1 - entropy(fused, eps) / math.log(m)).clamp_min(0)
    membership = torch.zeros(n, device=fused.device, dtype=fused.dtype)
    membership[selected_indices] = 1
    w = confidence * (1 + kappa * membership)
    denom = w.sum()
    if denom <= eps:
        return torch.full_like(w, 1 / n), w
    return w / denom, w


def per_sample_kl(reference, prediction, eps=1e-8):
    """KL(reference || prediction) for normalized categorical distributions."""
    return (reference * (reference.clamp_min(eps).log() - prediction.clamp_min(eps).log())).sum(-1)


def projection_loss(fused, predicted, global_pi, num_total, eps=1e-8):
    """Approximate full sum_i pi_i KL via uniform mini-batch scaling N/B.

    Uses global pi (not renormalized per batch). With fixed parameters this is
    an unbiased full-objective estimator under uniform random mini-batches.
    """
    return (global_pi * per_sample_kl(fused.detach(), predicted, eps)).mean() * num_total


def temporal_consistency_loss(p_clean, p_aug, eps=1e-8):
    """Eq. constraints: stop-gradient clean predictions vs strong view."""
    return per_sample_kl(p_clean.detach(), p_aug, eps).mean()


def mutual_information(p, eps=1e-8):
    """Eq. constraints: H(mean p) - mean_i H(p_i)."""
    return entropy(p.mean(0), eps) - entropy(p, eps).mean()
